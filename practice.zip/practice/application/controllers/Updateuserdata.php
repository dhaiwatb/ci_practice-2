<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Updateuserdata extends MY_Controller {
    public function __construct()
    {
        parent::__construct();
        //$this->load->model('studentdetails');
        $this->load->model("studentdetails");


    }
    public function index($id)
    {
        $this->load->view('updateprofile');        
    }
    public function displayData($id)
    {
        $data['user'] = $this->crudops->dispData($id);
        $this->load->view('updateprofile',$data);
    }
    public function updateUser($id)
    {
        $userid = $id;
        $username = $this->input->post('username'); 
        $password = $this->input->post('password');
        $firstname = $this->input->post('firstname');
        $lastname = $this->input->post('lastname');

        $this->crudops->updatedata($username,$password,$firstname,$lastname,$userid);
        
        return redirect('home');
    }
    public function adddetails()
    {   
        //$Cid = $this->input->post('countryid');
        $userId = $this->session->userdata('user_id');
        $data['users'] = $this->crudops->dispdata($userId);
        $data['countries'] = $this->getCountry();
        //$data['another_variable'] = $this->getState($Cid);
        $this->load->view('student_info',$data);
    }
    public function getCountry()
    {
        $data['country'] = $this->studentdetails->getCountry();        
        return $data;
    }
    public function getState($Cid = '')
    {
        $Cid = $this->input->post('countryid');
        $data['states'] = $this->studentdetails->getState($Cid);
        return $data;
    }
    public function getCity($Sid = '')
    {
        $Sid = $this->input->post('stateid');
        $data['city'] = $this->studentdetails->getCity($Sid);
        return $data;
    }
    public function addinfo()
    {
        echo "<pre>";
        print_r($this->input->post());

        if($this->session->has_userdata('user_id'))
        {
            $id = $this->session->userdata('user_id');
            if(is_array($this->input->post('gender')))
            {            
                $gender = $this->input->post('gender')[0]; 
            }
            if(is_array($this->input->post('hobby')))
            {            
                $hobby = implode(",",$this->input->post('hobby')); 
            }    
            $birthdate = date($this->input->post('birthdate'));

            $country = $this->input->post('country');
            $state = $this->input->post('state');
            $city = $this->input->post('city');
            echo $id."<br>".$gender."<br>".$hobby."<br>".$birthdate."<br>".$country."<br>".$state."<br>".$city;
            //$this->studentdetails->insertDetails($id,$gender,$hobby,$birthdate,$country,$state,$city)
            if($this->studentdetails->hasData($id))
            {
                if($this->form_validation->run('student_info'))
                {
                    $this->studentdetails->insertDetails($id,$gender,$hobby,$birthdate,$country,$state,$city);
                }
            }
        }
        else
            echo "fill form first";
    }
}