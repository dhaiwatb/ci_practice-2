<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {
    public function index(){

        $this->load->view('header');
        
        $attributes['formdata'] = array('class' => 'email', 'id' => 'loginform');

        $this->form_validation->set_rules('username','Username','required|alpha_numeric');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run() == FALSE)
        {
            $this->load->view('login',$attributes);
            //echo "form fail to load";
        }
        else
        {            
            $uname = $this->form->post('username');
            $pword = $this->form->post('password');
            if($this->crudops->checkLogin($uname,$pword))
            {
                $this->load->view('home');
            }
            else
            {
                $this->load->view('login',$attributes);
            }
        }

        $this->load->view('footer');
    }
}