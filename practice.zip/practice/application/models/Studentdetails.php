<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Studentdetails extends CI_Model
{
    public function retdatafromdb()
    {
        $id = $this->session->userdata('userid');         
        return $id;
    }
    public function getCity($stateID)
    {
        $q = $this->db->select('c.id,c.name')
        ->join('states s', 'c.stateID = s.id' )        
        ->where('s.id',$stateID)
        ->get('city c');
        $output = "<option value='0'>Select City</output>";
        foreach($q->result_object() as $row)
        {
            $output .= "<option value='".$row->id."'>".$row->name."</option>";
        }
        echo $output;  
    }
    public function getState($countryID)
    {
        $q = $this->db->select('s.id,s.name')
        ->join('country as c','s.countryID=c.id')
        ->where('countryID',$countryID)
        ->get('states as s');
        $output = "<option value='0'>Select State</output>";
        foreach($q->result_object() as $row)
        {
            $output .= "<option value='".$row->id."'>".$row->name."</option>";
        }
        echo $output;
    }
    public function getCountry()  
    {
        $q = $this->db->get('country');        

        return $q->result_array();
    }   
    public function insertDetails($id,$gender,$hobby,$birthdate,$country,$state,$city)
    {
        $insertdata = array(
            'gender' => $gender,
            'birthdate' => $birthdate,
            'hobbies' => $hobby,
            'city' => $city,
            'state' => $state,
            'country' => $country,
            'user_id' => $id
        );
        $q = $this->db
            ->set($insertdata)
            ->insert('student_details');
    }
    public function hasData($id)
    {
        $q = $this->db->get('student_details')
        ->where('user_id',$id);

        if($q->result())
            return true;
        else
            return false;
    }
}