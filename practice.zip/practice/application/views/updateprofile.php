<?php include('header.php'); ?>
<?php $values = $user[0]; ?>

<div class="row">
    <div class="col-lg-8">
        <h1>
            <p>Update Details</p>
            <hr>
        </h1>

    </div>
    <div class="col-lg-4 mt-3">
        <a href="<?=base_url().'updateuserdata/adddetails/'?>">
            <button class="btn btn-info">
                <span class="glyphicon glyphicon-plus"></span> Add details
            </button>
        </a>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 mx-auto">
        <table class="table">
            <?=form_open(base_url().'updateuserdata/updateuser/'.$values['id'],['class'=>'form'])?>
                <tr>
                    <td>Username</td>
                    <td>
                        <?=form_input(['name'=>'username','value'=>$values['uname'],'class'=>'form-control'])?>
                    </td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td>
                        <?=form_password(['name'=>'password','value'=>$values['pword'],'class'=>'form-control'])?>
                    </td>
                </tr>
                <tr>
                    <td>Firstname</td>
                    <td>
                        <?=form_input(['name'=>'firstname','value'=>$values['fname'],'class'=>'form-control'])?>
                    </td>
                </tr>
                <tr>
                    <td>Lastname</td>
                    <td>
                        <?=form_input(['name'=>'lastname','value'=>$values['lname'],'class'=>'form-control'])?>
                    </td>
                </tr>
                <tr >
                    <td  colspan="2">
                        <?=form_hidden(['name'=>'userid','value'=>$values['id']]);?>
                        <?=form_submit('submit', 'Submit',array('class'=>'btn btn-primary')); ?>
                        <?=form_reset('reset', 'Clean',array('class'=>'btn btn-danger'));?>
                    </td>
                </tr>
            <?php echo form_close();  ?>
        </table>
    </div>

    <div class="col-lg-4 d-flex align-items-center">
        <img src="<?=$values['image_path']?>" alt="" class="img-fluid rounded-circle ">
    </div>
</div>
<?php include('footer.php'); ?>