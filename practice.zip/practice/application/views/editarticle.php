<?php include('header.php') ?>
<?php 
    $articledata = ['name'=>'article_form','class'=>'form'];
    $data = $article[0];
?>
<div class="row">
    <div class="col-lg-12">
        <h1>Edit Article</h1>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <?php echo form_open(base_url().'article/editarticle/'.$data['id'],$articledata); ?>
            <div class="form-group">
                <?=form_label('Article Title','title')?>
                <?=form_input(['name'=>'title','class'=>'form-control','auto-focus'=>'true','value'=>$data['title']])?>
            </div>
            <div class="form-group">
                <?=form_label('Description','description')?>
                <?=form_textarea(['name'=>'description','rows'=>'4','class'=>'form-control','value'=>$data['description']])?>
            </div>
            <div class="form-group">
                <?=form_hidden(['name'=>'articleid','value'=>$data['id']])?>
                <?=form_submit(['name'=>'submit','value'=>'Submit','class'=>"btn btn-primary"])?>
                <?=form_reset(['name'=>'reset','value'=>'Clear','class'=>"btn btn-danger"])?>
            </div>
        <?php echo form_close(); ?>
    </div>
</div>
<?php include('footer.php') ?>