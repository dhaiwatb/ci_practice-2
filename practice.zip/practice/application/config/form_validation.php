<?php

$config = array(
    'login_form'=>array(
        array(
            'field' => 'username',
            'label' => 'Username',
            'rules' => 'required|callback_checkUserAvail'
        ),
        array(
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required'
        )
    ),
    'signup_form'=>array(
        array(
            'field' => 'username',
            'label' => 'Username',
            'rules' => 'required|is_unique[student_info.uname]',
            'errors' => array( 
                'is_unique'     => 'This %s already exists.'
            )
        ),
        array(
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required'
        ),
        array(
            'field' => 'firstname',
            'label' => 'Firstname',
            'rules' => 'required'
        ),
        array(
            'field' => 'lastname',
            'label' => 'Lastname',
            'rules' => 'required'
        )
    ),
    'article_form' => array(
        array(
            'field' => 'title',
            'label' => 'Title',
            'rules' => 'required'
        )
    )
);